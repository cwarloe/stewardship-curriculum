---
name: New Lesson Request
about: Propose a new module or lesson for the curriculum
---
**Lesson Title:**

**Description:**

**Scripture & Resources:**
